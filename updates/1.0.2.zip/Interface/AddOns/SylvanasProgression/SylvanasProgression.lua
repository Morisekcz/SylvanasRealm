------------------------------------------------------------
-- SylvanasProgression
-- WotLK 3.3.5a
------------------------------------------------------------

local SP = {}
_G["SylvanasProgression"] = SP

------------------------------------------------------------
-- SETTINGS
------------------------------------------------------------

SP.CurrentTier = nil
SP.WaitingForProgression = false
SP.LastReceivedTier = nil

SP.WindowWidth = 600
SP.WindowHeight = 600

------------------------------------------------------------
-- TIERS
------------------------------------------------------------

SP.Tiers = {

    [0] = {
        name = "Molten Core / Onyxia",
        level = 60,
        description = "Classic progression begins."
    },

    [1] = {
        name = "Blackwing Lair",
        level = 60,
        description = "Blackwing Lair progression."
    },

    [2] = {
        name = "Pre-Ahn'Qiraj",
        level = 60,
        description = "Ahn'Qiraj War Effort preparation."
    },

    [3] = {
        name = "Ahn'Qiraj War",
        level = 60,
        description = "The Ahn'Qiraj War begins."
    },

    [4] = {
        name = "Ahn'Qiraj",
        level = 60,
        description = "Temple of Ahn'Qiraj progression."
    },

    [5] = {
        name = "Naxxramas",
        level = 60,
        description = "Classic endgame progression."
    },

    [6] = {
        name = "Pre-TBC",
        level = 60,
        description = "Preparation for The Burning Crusade."
    },

    [7] = {
        name = "Karazhan / Gruul / Magtheridon",
        level = 70,
        description = "The Burning Crusade begins."
    },

    [8] = {
        name = "Serpentshrine Cavern / Tempest Keep",
        level = 70,
        description = "Burning Crusade Tier 5 progression."
    },

    [9] = {
        name = "Mount Hyjal / Black Temple",
        level = 70,
        description = "Burning Crusade Tier 6 progression."
    },

    [10] = {
        name = "Zul'Aman",
        level = 70,
        description = "Optional Zul'Aman progression."
    },

    [11] = {
        name = "Pre-Sunwell",
        level = 70,
        description = "Preparation for Sunwell Plateau."
    },

    [12] = {
        name = "Sunwell Plateau",
        level = 70,
        description = "Final Burning Crusade raid progression."
    },

    [13] = {
        name = "Naxxramas / Eye of Eternity / Obsidian Sanctum",
        level = 80,
        description = "Wrath of the Lich King begins."
    },

    [14] = {
        name = "Ulduar",
        level = 80,
        description = "Ulduar progression."
    },

    [15] = {
        name = "Trial of the Crusader",
        level = 80,
        description = "Trial of the Crusader progression."
    },

    [16] = {
        name = "Icecrown Citadel",
        level = 80,
        description = "Icecrown Citadel progression."
    },

    [17] = {
        name = "Ruby Sanctum",
        level = 80,
        description = "Final WotLK progression."
    }
}

------------------------------------------------------------
-- CREATE WINDOW
------------------------------------------------------------

function SP:CreateWindow()

    if self.Window then
        return
    end

    local frame = CreateFrame(
        "Frame",
        "SylvanasProgressionFrame",
        UIParent
    )

    self.Window = frame

    frame:SetWidth(self.WindowWidth)
    frame:SetHeight(self.WindowHeight)

    frame:SetPoint(
        "CENTER",
        UIParent,
        "CENTER",
        0,
        0
    )

    frame:SetBackdrop({
        bgFile = "Interface\\DialogFrame\\UI-DialogBox-Background",
        edgeFile = "Interface\\DialogFrame\\UI-DialogBox-Border",
        tile = true,
        tileSize = 32,
        edgeSize = 32,
        insets = {
            left = 11,
            right = 12,
            top = 12,
            bottom = 11
        }
    })

    frame:SetBackdropColor(
        0.12,
        0.10,
        0.07,
        0.96
    )

    frame:SetMovable(true)
    frame:EnableMouse(true)
    frame:RegisterForDrag("LeftButton")

    frame:SetScript(
        "OnDragStart",
        function()
            this:StartMoving()
        end
    )

    frame:SetScript(
        "OnDragStop",
        function()
            this:StopMovingOrSizing()
        end
    )

    --------------------------------------------------------
    -- TITLE
    --------------------------------------------------------

    local title = frame:CreateFontString(
        nil,
        "OVERLAY",
        "GameFontNormalLarge"
    )

    title:SetPoint(
        "TOP",
        frame,
        "TOP",
        0,
        -22
    )

    title:SetText(
        "SYLVANAS REALM"
    )

    title:SetTextColor(
        1.0,
        0.82,
        0.20
    )

    --------------------------------------------------------
    -- SUBTITLE
    --------------------------------------------------------

    local subtitle = frame:CreateFontString(
        nil,
        "OVERLAY",
        "GameFontNormalSmall"
    )

    subtitle:SetPoint(
        "TOP",
        frame,
        "TOP",
        0,
        -43
    )

    subtitle:SetText(
        "INDIVIDUAL PROGRESSION"
    )

    subtitle:SetTextColor(
        0.65,
        0.65,
        0.65
    )

    --------------------------------------------------------
    -- CLOSE BUTTON
    --------------------------------------------------------

    local closeButton = CreateFrame(
        "Button",
        nil,
        frame,
        "UIPanelCloseButton"
    )

    closeButton:SetPoint(
        "TOPRIGHT",
        frame,
        "TOPRIGHT",
        -5,
        -5
    )

    closeButton:SetScript(
        "OnClick",
        function()
            SP.Window:Hide()
        end
    )

    --------------------------------------------------------
    -- CHARACTER PANEL
    --------------------------------------------------------

    local characterPanel = CreateFrame(
        "Frame",
        nil,
        frame
    )

    characterPanel:SetWidth(540)
    characterPanel:SetHeight(58)

    characterPanel:SetPoint(
        "TOP",
        frame,
        "TOP",
        0,
        -65
    )

    characterPanel:SetBackdrop({
        bgFile = "Interface\\Tooltips\\UI-Tooltip-Background",
        edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border",
        tile = true,
        tileSize = 16,
        edgeSize = 12,
        insets = {
            left = 4,
            right = 4,
            top = 4,
            bottom = 4
        }
    })

    characterPanel:SetBackdropColor(
        0.18,
        0.15,
        0.10,
        0
    )

    --------------------------------------------------------
    -- CHARACTER
    --------------------------------------------------------

    local character = frame:CreateFontString(
        nil,
        "OVERLAY",
        "GameFontNormal"
    )

    self.CharacterText = character

    character:SetPoint(
        "TOPLEFT",
        characterPanel,
        "TOPLEFT",
        16,
        -12
    )

    character:SetTextColor(
        0.80,
        0.80,
        0.80
    )

    --------------------------------------------------------
    -- CURRENT
    --------------------------------------------------------

    local current = frame:CreateFontString(
        nil,
        "OVERLAY",
        "GameFontNormalLarge"
    )

    self.CurrentText = current

    current:SetPoint(
        "TOPLEFT",
        characterPanel,
        "TOPLEFT",
        16,
        -34
    )

    current:SetTextColor(
        1.0,
        0.82,
        0.20
    )

    --------------------------------------------------------
    -- REFRESH BUTTON
    --------------------------------------------------------

    local refreshButton = CreateFrame(
        "Button",
        "SylvanasProgressionRefreshButton",
        frame,
        "UIPanelButtonTemplate"
    )

    refreshButton:SetWidth(105)
    refreshButton:SetHeight(24)

    refreshButton:SetPoint(
        "RIGHT",
        characterPanel,
        "RIGHT",
        -12,
        0
    )

    refreshButton:SetText(
        "REFRESH"
    )

    refreshButton:SetScript(
        "OnClick",
        function()
            SP:Refresh()
        end
    )

    --------------------------------------------------------
    -- NEXT
    --------------------------------------------------------

    local nextTier = frame:CreateFontString(
        nil,
        "OVERLAY",
        "GameFontNormal"
    )

    self.NextText = nextTier

    nextTier:SetPoint(
        "TOPLEFT",
        frame,
        "TOPLEFT",
        30,
        -137
    )

    nextTier:SetTextColor(
        0.75,
        0.75,
        0.75
    )

    --------------------------------------------------------
    -- DESCRIPTION
    --------------------------------------------------------

    local description = frame:CreateFontString(
        nil,
        "OVERLAY",
        "GameFontHighlight"
    )

    self.DescriptionText = description

    description:SetPoint(
        "TOPLEFT",
        frame,
        "TOPLEFT",
        30,
        -160
    )

    description:SetWidth(540)
    description:SetJustifyH("LEFT")

    description:SetTextColor(
        0.65,
        0.65,
        0.65
    )

    --------------------------------------------------------
    -- JOURNAL TITLE
    --------------------------------------------------------

    local listTitle = frame:CreateFontString(
        nil,
        "OVERLAY",
        "GameFontNormalLarge"
    )

    listTitle:SetPoint(
        "TOPLEFT",
        frame,
        "TOPLEFT",
        30,
        -198
    )

    listTitle:SetText(
        "PROGRESSION JOURNAL"
    )

    listTitle:SetTextColor(
        1.0,
        0.82,
        0.20
    )

    --------------------------------------------------------
    -- SEPARATOR
    --------------------------------------------------------

    local separator = frame:CreateTexture(
        nil,
        "ARTWORK"
    )

    separator:SetTexture(
        "Interface\\Buttons\\WHITE8X8"
    )

    separator:SetPoint(
        "TOPLEFT",
        frame,
        "TOPLEFT",
        30,
        -220
    )

    separator:SetWidth(540)
    separator:SetHeight(1)

    separator:SetVertexColor(
        0.45,
        0.36,
        0.15,
        0.8
    )

    --------------------------------------------------------
    -- COLUMN HEADERS
    --------------------------------------------------------

    local tierHeader = frame:CreateFontString(
        nil,
        "OVERLAY",
        "GameFontNormalSmall"
    )

    tierHeader:SetPoint(
        "TOPLEFT",
        frame,
        "TOPLEFT",
        38,
        -232
    )

    tierHeader:SetText(
        "TIER"
    )

    tierHeader:SetTextColor(
        0.85,
        0.70,
        0.35
    )

    local contentHeader = frame:CreateFontString(
        nil,
        "OVERLAY",
        "GameFontNormalSmall"
    )

    contentHeader:SetPoint(
        "TOPLEFT",
        frame,
        "TOPLEFT",
        105,
        -232
    )

    contentHeader:SetText(
        "CONTENT"
    )

    contentHeader:SetTextColor(
        0.85,
        0.70,
        0.35
    )

    local levelHeader = frame:CreateFontString(
        nil,
        "OVERLAY",
        "GameFontNormalSmall"
    )

    levelHeader:SetPoint(
        "TOPRIGHT",
        frame,
        "TOPRIGHT",
        -40,
        -232
    )

    levelHeader:SetText(
        "LEVEL"
    )

    levelHeader:SetTextColor(
        0.85,
        0.70,
        0.35
    )

    --------------------------------------------------------
    -- JOURNAL BACKGROUND
    --------------------------------------------------------

    local journalPanel = CreateFrame(
        "Frame",
        nil,
        frame
    )

    journalPanel:SetWidth(540)
    journalPanel:SetHeight(335)

    journalPanel:SetPoint(
        "TOP",
        frame,
        "TOP",
        0,
        -242
    )

    journalPanel:SetBackdrop({
        bgFile = "Interface\\Tooltips\\UI-Tooltip-Background",
        edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border",
        tile = true,
        tileSize = 16,
        edgeSize = 12,
        insets = {
            left = 4,
            right = 4,
            top = 4,
            bottom = 4
        }
    })

    journalPanel:SetBackdropColor(
        0.08,
        0.065,
        0.045,
        0.92
    )

    journalPanel:SetFrameLevel(
        frame:GetFrameLevel() + 1
    )

    --------------------------------------------------------
    -- TIER ROWS
    --------------------------------------------------------

    self.Rows = {}

    local startY = -252
    local rowHeight = 18

    for tier = 0, 17 do

        local row = CreateFrame(
            "Frame",
            nil,
            journalPanel
        )

        row:SetWidth(540)
        row:SetHeight(18)

        row:SetPoint(
            "TOPLEFT",
            journalPanel,
            "TOPLEFT",
            0,
            -10 - (tier * rowHeight)
        )

        local tierText = row:CreateFontString(
            nil,
            "OVERLAY",
            "GameFontNormal"
        )

        tierText:SetPoint(
            "LEFT",
            row,
            "LEFT",
            8,
            0
        )

        tierText:SetWidth(55)
        tierText:SetJustifyH("LEFT")

        local nameText = row:CreateFontString(
            nil,
            "OVERLAY",
            "GameFontNormal"
        )

        nameText:SetPoint(
            "LEFT",
            row,
            "LEFT",
            75,
            0
        )

        nameText:SetWidth(390)
        nameText:SetJustifyH("LEFT")

        local levelText = row:CreateFontString(
            nil,
            "OVERLAY",
            "GameFontNormal"
        )

        levelText:SetPoint(
            "RIGHT",
            row,
            "RIGHT",
            -8,
            0
        )

        levelText:SetWidth(45)
        levelText:SetJustifyH("RIGHT")

        self.Rows[tier] = {
            frame = row,
            tier = tierText,
            name = nameText,
            level = levelText
        }

    end

    --------------------------------------------------------
    -- FOOTER
    --------------------------------------------------------

    local footer = frame:CreateFontString(
        nil,
        "OVERLAY",
        "GameFontNormalSmall"
    )

    footer:SetPoint(
        "BOTTOM",
        frame,
        "BOTTOM",
        0,
        15
    )

    footer:SetText(
        "Your progression is saved per character."
    )

    footer:SetTextColor(
        0.45,
        0.45,
        0.45
    )

    self:SetUnknown()

end

------------------------------------------------------------
-- MINIMAP BUTTON
------------------------------------------------------------

local minimapButton = CreateFrame(
    "Button",
    "SylvanasProgressionMinimapButton",
    Minimap
)

minimapButton:SetWidth(32)
minimapButton:SetHeight(32)

minimapButton:SetFrameStrata("MEDIUM")
minimapButton:SetFrameLevel(8)

minimapButton:SetPoint(
    "TOPLEFT",
    Minimap,
    "TOPLEFT",
    -2,
    -2
)

minimapButton:SetNormalTexture(
    "Interface\\Minimap\\UI-Minimap-ZoomIn"
)

minimapButton:SetHighlightTexture(
    "Interface\\Minimap\\UI-Minimap-ZoomIn"
)

minimapButton:SetScript(
    "OnClick",
    function()
        if SP.Window and SP.Window:IsShown() then
            SP.Window:Hide()
        else
            SP:Show()
        end
    end
)

minimapButton:SetScript(
    "OnEnter",
    function()
        GameTooltip:SetOwner(
            this,
            "ANCHOR_LEFT"
        )

        GameTooltip:SetText(
            "Sylvanas Progression"
        )

        GameTooltip:AddLine(
            "Click to open your progression journal.",
            0.8,
            0.8,
            0.8
        )

        GameTooltip:Show()
    end
)

minimapButton:SetScript(
    "OnLeave",
    function()
        GameTooltip:Hide()
    end
)

------------------------------------------------------------
-- UNKNOWN
------------------------------------------------------------

function SP:SetUnknown()

    if not self.Window then
        return
    end

    self.CurrentText:SetText(
        "Current Progression: UNKNOWN"
    )

    self.NextText:SetText(
        "Waiting for server..."
    )

    self.DescriptionText:SetText(
        "Checking your IndividualProgression..."
    )

    self.CharacterText:SetText(
        "Character: " ..
        UnitName("player") ..
        "   Level: " ..
        tostring(UnitLevel("player"))
    )

    for tier = 0, 17 do

        local data = self.Tiers[tier]
        local row = self.Rows[tier]

        row.tier:SetText(
            "Tier " .. tostring(tier)
        )

        row.name:SetText(
            data.name
        )

        row.level:SetText(
            tostring(data.level)
        )

        row.tier:SetTextColor(
            0.7,
            0.7,
            0.7
        )

        row.name:SetTextColor(
            0.7,
            0.7,
            0.7
        )

        row.level:SetTextColor(
            0.7,
            0.7,
            0.7
        )

    end

end

------------------------------------------------------------
-- UPDATE WINDOW
------------------------------------------------------------

function SP:UpdateWindow()

    if not self.Window then
        return
    end

    if self.CurrentTier == nil then
        self:SetUnknown()
        return
    end

    local tier = tonumber(self.CurrentTier)

    if not tier then
        self:SetUnknown()
        return
    end

    local data = self.Tiers[tier]

    if not data then
        self:SetUnknown()
        return
    end

    --------------------------------------------------------
    -- CHARACTER
    --------------------------------------------------------

    self.CharacterText:SetText(
        "Character: " ..
        UnitName("player") ..
        "   Level: " ..
        tostring(UnitLevel("player"))
    )

    --------------------------------------------------------
    -- CURRENT
    --------------------------------------------------------

    self.CurrentText:SetText(
        "Current Progression: Tier " ..
        tostring(tier) ..
        " - " ..
        data.name
    )

    --------------------------------------------------------
    -- NEXT
    --------------------------------------------------------

    local nextData = self.Tiers[tier + 1]

    if nextData then

        self.NextText:SetText(
            "Next Tier: " ..
            tostring(tier + 1) ..
            " - " ..
            nextData.name
        )

    else

        self.NextText:SetText(
            "Next Tier: Final progression"
        )

    end

    --------------------------------------------------------
    -- DESCRIPTION
    --------------------------------------------------------

    self.DescriptionText:SetText(
        data.description ..
        "  Recommended level: " ..
        tostring(data.level)
    )

    --------------------------------------------------------
    -- COLORS
    --------------------------------------------------------

    for i = 0, 17 do

        local row = self.Rows[i]

        if i < tier then

            row.tier:SetTextColor(
                0.4,
                1.0,
                0.4
            )

            row.name:SetTextColor(
                0.4,
                1.0,
                0.4
            )

            row.level:SetTextColor(
                0.4,
                1.0,
                0.4
            )

        elseif i == tier then

            row.tier:SetTextColor(
                1.0,
                0.82,
                0.0
            )

            row.name:SetTextColor(
                1.0,
                0.82,
                0.0
            )

            row.level:SetTextColor(
                1.0,
                0.82,
                0.0
            )

        else

            row.tier:SetTextColor(
                0.65,
                0.65,
                0.65
            )

            row.name:SetTextColor(
                0.65,
                0.65,
                0.65
            )

            row.level:SetTextColor(
                0.65,
                0.65,
                0.65
            )

        end

    end

end

------------------------------------------------------------
-- PARSE SERVER RESPONSE
------------------------------------------------------------

function SP:ParseProgressionMessage(msg)

    if not msg then
        return false
    end

    msg = tostring(msg)

    --------------------------------------------------------
    -- We only care about the IndividualProgression response.
    --
    -- Expected server message:
    --
    -- Progression level for Moriska = 3
    --------------------------------------------------------

    local lowerMessage = string.lower(msg)

    if not string.find(
        lowerMessage,
        "progression level for"
    ) then

        return false

    end

    --------------------------------------------------------
    -- Find the LAST NUMBER in the message.
    --
    -- This avoids problems with names, spaces or formatting.
    --------------------------------------------------------

    local tier = nil

    for number in string.gmatch(
        msg,
        "%d+"
    ) do

        tier = number

    end

    if not tier then
        return false
    end

    tier = tonumber(tier)

    --------------------------------------------------------
    -- Only accept valid IndividualProgression tiers.
    --------------------------------------------------------

    if tier < 0 or tier > 17 then
        return false
    end

    --------------------------------------------------------
    -- Prevent the same server response from being processed
    -- repeatedly.
    --------------------------------------------------------

    if self.LastReceivedTier == tier and
       self.WaitingForProgression == false then

        return true

    end

    --------------------------------------------------------
    -- SAVE TIER
    --------------------------------------------------------

    self.CurrentTier = tier
    self.LastReceivedTier = tier
    self.WaitingForProgression = false

    --------------------------------------------------------
    -- UPDATE UI
    --------------------------------------------------------

    if self.Window then
        self:UpdateWindow()
    end

    return true

end

------------------------------------------------------------
-- CHATFRAME HOOK
------------------------------------------------------------

local function HookChatFrame(frame)

    if not frame then
        return
    end

    if not frame.AddMessage then
        return
    end

    hooksecurefunc(
        frame,
        "AddMessage",
        function(chatFrame, text)

            if not text then
                return
            end

            SP:ParseProgressionMessage(text)

        end
    )

end

------------------------------------------------------------
-- HOOK ALL CHAT FRAMES
------------------------------------------------------------

if NUM_CHAT_WINDOWS then

    for i = 1, NUM_CHAT_WINDOWS do

        local chatFrame = _G[
            "ChatFrame" .. tostring(i)
        ]

        if chatFrame then
            HookChatFrame(chatFrame)
        end

    end

end

------------------------------------------------------------
-- REQUEST PROGRESSION
------------------------------------------------------------

function SP:RequestProgression()

    self.WaitingForProgression = true

    SendChatMessage(
        ".ip get",
        "SAY"
    )

end

------------------------------------------------------------
-- SHOW
------------------------------------------------------------

function SP:Show()

    if not self.Window then
        self:CreateWindow()
    end

    self.Window:Show()

    self:RequestProgression()

end

------------------------------------------------------------
-- REFRESH
------------------------------------------------------------

function SP:Refresh()

    if not self.Window then
        self:CreateWindow()
    end

    self:RequestProgression()

end

------------------------------------------------------------
-- DEBUG
------------------------------------------------------------

function SP:Debug()

    DEFAULT_CHAT_FRAME:AddMessage(
        "|cffffcc00===== SylvanasProgression DEBUG =====|r"
    )

    DEFAULT_CHAT_FRAME:AddMessage(
        "CurrentTier = " ..
        tostring(self.CurrentTier)
    )

    DEFAULT_CHAT_FRAME:AddMessage(
        "LastReceivedTier = " ..
        tostring(self.LastReceivedTier)
    )

    DEFAULT_CHAT_FRAME:AddMessage(
        "WaitingForProgression = " ..
        tostring(self.WaitingForProgression)
    )

    DEFAULT_CHAT_FRAME:AddMessage(
        "ChatFrame1.AddMessage = " ..
        tostring(
            ChatFrame1 and
            ChatFrame1.AddMessage ~= nil
        )
    )

    DEFAULT_CHAT_FRAME:AddMessage(
        "========================================"
    )

end

------------------------------------------------------------
-- SLASH COMMAND /ip
------------------------------------------------------------

SLASH_SYLVANASPROGRESSION1 = "/ip"

SlashCmdList["SYLVANASPROGRESSION"] = function(msg)

    if not msg then
        msg = ""
    end

    msg = string.lower(msg)

    if msg == "refresh" then

        SP:Refresh()

    elseif msg == "debug" then

        SP:Debug()

    else

        SP:Show()

    end

end

------------------------------------------------------------
-- SLASH COMMAND /iprefresh
------------------------------------------------------------

SLASH_SYLVANASPROGRESSIONREFRESH1 = "/iprefresh"

SlashCmdList["SYLVANASPROGRESSIONREFRESH"] = function()

    SP:Refresh()

end

------------------------------------------------------------
-- SLASH COMMAND /ipdebug
------------------------------------------------------------

SLASH_SYLVANASPROGRESSIONDEBUG1 = "/ipdebug"

SlashCmdList["SYLVANASPROGRESSIONDEBUG"] = function()

    SP:Debug()

end

------------------------------------------------------------
-- PLAYER LOGIN
------------------------------------------------------------

local loginFrame = CreateFrame(
    "Frame"
)

loginFrame:RegisterEvent(
    "PLAYER_LOGIN"
)

loginFrame:SetScript(
    "OnEvent",
    function()

        if not SP.Window then
            SP:CreateWindow()
        end

        DEFAULT_CHAT_FRAME:AddMessage(
            "|cffffcc00Sylvanas Realm:|r " ..
            "Progression Journal loaded."
        )

    end
)

------------------------------------------------------------
-- END
------------------------------------------------------------
